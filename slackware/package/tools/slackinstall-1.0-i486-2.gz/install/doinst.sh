#!/bin/sh
#
# postinstall script, created by checkinstall-1.6.0beta3
#
echo
ldconfig
