#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* ORIGINAL  JAVA HEADER
 * Created: Fri Mar 15 10:59:56 2002
 * $Log: TextToRTF.java,v $
 * Revision 1.4  2002/05/14 20:53:36  richard
 * added in formfeed to \page conversion
 *
 * Revision 1.3  2002/04/15 22:33:10  sean
 * removed superfluous imports
 *
 * Revision 1.2  2002/03/15 03:59:20  richard
 * put in font size tag
 *
 * Revision 1.1  2002/03/15 02:06:32  richard
 * escaping characters
 *
 */
/**
 * A simple text to Rich Text Format converter.
 *
 * @author Richard Littin (richard@reeltwo.com)
 * @version $Revision: 1.4 $
 *
 */
/*
    Adapted to C with command line options
    8/12/2003 Matthew Weinstein (mweinste@kent.edu)
*/
/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



*/

int main (int argc, const char * argv[]) {
	int i;
	int ch, fcnt;
        char cc, c1, c2, c3;
	char outName[200];
 	FILE *ifile;
        FILE *ofile;
        
        c1=c2=c3=cc=0;
        fcnt = 0;
        if(argc <= 1)
        {
            c1 = 't';
            c2 = 1;
            c3 = 1;
            fcnt = 3;
        }else
        if(argv[1][0] == '-')
        {
            for(i = 1; i < strlen(argv[1]); i++)
            {
                cc = argv[1][i];
                switch(cc)
                {
                    case 'h':
            printf("usage: text2rtf [-[t|c]IO] filenames\nt = times; c = courier\nversion 1.0\nI = stdin\nO=stdout\n\n");
            exit(0);
                    break;
                    
                    case 'c':
                        c1 = 'c';
                        break;
                    case 't':
                        c1 = 't';
                        break;
                        
                    case 'I':
                        c2 = 1;
                        fcnt = 3;
                        break;
                        
                    case 'O':
                        c3 = 1;
                        break;
                    default:;
                }

            }
        }
        
        if(c2 != 1)
            fcnt = argc;

	for (i = 2; i < fcnt; i++)
	{

                if(c2) 
                {
                    ifile = stdin;
                    c3 = 1;
                }
                
                else if((ifile = fopen(argv[i], "r")) == NULL)
                {
                        fprintf(stderr, "Could not open %s\n", argv[i]);
                        continue;
                }
                if(c3 != 1) {
                    sprintf(outName,"%s.rtf",argv[i]);
                    ofile = fopen (outName, "w");
                }
                else
                    ofile = stdout;
                    
		fputs("{\\rtf1\\mac\\ansicpg10000\\cocoartf102\n", ofile);  
                if (c1 == 'c')
                    fputs("{\\fonttbl\\f0\\froman\\fcharset77 Courier;}\n", ofile);
                else
                    fputs("{\\fonttbl\\f0\\froman\\fcharset77 Times-Roman;}\n", ofile);

   		fputs("\\f0\\fs24\n", ofile);
		while((ch = fgetc(ifile)) != EOF) 
		{
       		 	if (ch == 9) {
          		fputs("\\tab ", ofile);
        		} else if (ch == 12) { // formfeed
         			 fputs("\\page",ofile);
        		} else if (ch == '\\') {
          			fputs("\\\\",ofile);
        		} else if (ch == '{') {
          			fputs("\\{",ofile);
        		} else if (ch == '}') {
         			 fputs("\\}",ofile);
        		} 
 			else if(ch == '\n')
      				fputs("\n\\par ",ofile);
                       else if (ch < ' ' || ch >= 128)
				 {fprintf(ofile,"\\%X",ch);}

        		 else {
          			fputc(ch,ofile);
        		}
      		}

	   	fputs("}", ofile);
		fclose (ofile); fclose(ifile);
	}
    return 0;
}
