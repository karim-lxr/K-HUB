This program converts text to rtf files. 

To install switch into the directory with all the files and type "make". 
Then copy the resulting file "text2rtf" to /usr/bin or /usr/bin. 

so move to the directory with the program and other documents and type

make
sudo cp text2rtf /usr/bin


To get help type:
text2rtf -h


