(* $I1: Unison file synchronizer: src/linktext.ml $ *)
(* $I2: Last modified by bcpierce on Mon, 19 Jul 1999 18:14:04 -0400 $ *)
(* $I3: Copyright 1999-2002 (see COPYING for details) $ *)

module TopLevel = Main.Body(Uitext.Body)
