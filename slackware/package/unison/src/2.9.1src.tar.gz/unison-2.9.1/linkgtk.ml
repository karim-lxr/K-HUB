(* $I1: Unison file synchronizer: src/linkgtk.ml $ *)
(* $I2: Last modified by vouillon on Wed, 26 Apr 2000 20:04:29 -0400 $ *)
(* $I3: Copyright 1999-2002 (see COPYING for details) $ *)

module TopLevel = Main.Body(Uigtk.Body)
