#define LETTER_PS 1
#define LETTER_CC 2
#define LETTER_ENCL 3

void CmdLetter(int code);
void CmdAddress(int code);
void CmdSignature(int code);
void CmdOpening(int code);
void CmdClosing(int code);
void CmdPs(int code);
