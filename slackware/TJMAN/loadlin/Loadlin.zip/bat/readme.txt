contenuto BAT


menuOK		batch menu funzionante per Win e Linux

multiGEN	batch menu per scelte multiple (esempi)

original		dir backup file originali